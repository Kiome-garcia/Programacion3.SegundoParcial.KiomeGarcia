import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;


public class GarajeApp extends Application{
    private static final String ARCHIVO_DAT = "garaje.txt";
    private static final String ARCHIVO_BITACORA = "bitacora.txt";

     private final ObservableList<Vehiculo> vehiculos = FXCollections.observableArrayList();
     private TableView<Vehiculo> tabla;
     private TextField txtplaca,txtmodelo,txtVelocidad,txtprecio;
     private ComboBox<String> cmbtipo;

     @Override
     public void start(Stage stage){
        cargarPartida();

        txtplaca = new TextField();
        txtmodelo = new TextField();
        txtVelocidad = new TextField();
        txtprecio = new TextField();
        cmbtipo = new ComboBox<>(FXCollections.observableArrayList("Motocicleta","Deportivo","Lancha","SUV","Avioneta"));
        cmbtipo.setPromptText("Seleccione el tipo de vehiculo");
        
        GridPane form = new GridPane();
        form.setHgap(10);
        form.setVgap(10);
        form.setPadding(new Insets(10));
        form.addRow(0, new Label("placa:"), txtplaca);
        form.addRow(1, new Label("modelo:"), txtmodelo);
        form.addRow(2, new Label("tipo:"), cmbtipo);
        form.addRow(3, new Label("Velocidad maxima (km/h):"), txtVelocidad);
        form.addRow(4, new Label("Precio ($):"), txtprecio);


        tabla = new TableView<>(vehiculos);
        tabla.getColumns().addAll(columna("placa", "placa"),columna("Modelo","modelo"),columna("Tipo","tipo"),columna("Velocidadmaxima","velocidadmaxima"),columna("Precio","precio"));
        tabla.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        Button btnAgregar = new Button("Agregar");
        Button btnEliminar = new Button("Eliminar seleccionado");
        Button btnLimpiar = new Button("Limpiar formulario");
        Button btnExportar = new Button("Exportar CSV");
        Button btnImportar = new Button("Importar CSV");
        Button bntGuardar = new Button("Guardar partida");

        btnAgregar.setOnAction(e-> agregar());
        btnEliminar.setOnAction(e-> eliminar());
        btnLimpiar.setOnAction(e-> limpiar());
        btnExportar.setOnAction(e-> exportarCSV(stage));
        btnImportar.setOnAction(e-> importarCSV(stage));
        bntGuardar.setOnAction(e-> guardarpartida());

         HBox botones = new HBox(10, btnAgregar, btnEliminar,btnLimpiar,btnExportar,btnImportar,bntGuardar);
         botones.setPadding(new Insets(10));
         
         //Layout

         BorderPane root = new BorderPane();
        root.setTop(form);
        root.setCenter(tabla);
        root.setBottom(botones);
        stage.setTitle("Garaje de Vice City");
        stage.setScene(new Scene(root, 850, 500));
        stage.show();
     }

      private <T> TableColumn<Vehiculo, T> columna(String titulo, String propiedad){
       TableColumn<Vehiculo, T> col = new TableColumn<>(titulo);
       col.setCellValueFactory(new PropertyValueFactory<>(propiedad));
       return col;
      }

       //Validaciones y Acciones

       private void agregar(){
        String placa = txtplaca.getText().trim();
        String modelo = txtmodelo.getText().trim();
        String tipo = cmbtipo.getValue();
        String vel = txtVelocidad.getText().trim();
        String preciotxt = txtprecio.getText().trim();

         if (placa.isEmpty() || modelo.isEmpty() || tipo == null
               || vel.isEmpty() || preciotxt.isEmpty()){
           mostrarError("Todos los campos son obligatorios.");
           return;
       }
       int velocidad, precio;
       try {
           velocidad = Integer.parseInt(vel);
           precio = Integer.parseInt(preciotxt);
       } catch (NumberFormatException ex) {
           mostrarError("Velocidad y precio deben ser numeros enteros.");
           return;
        }
         if (velocidad <= 0){
           mostrarError("La velocidad maxima debe ser mayor que 0.");
           return;
       }
       if(precio < 0){
        mostrarError("El precio no puede estar en negativo");
        return;
       }
       if(ExistePlaca(placa)){
        mostrarError("Ya existe un vehiculo con la placa" + placa);
        return;
       }
       Vehiculo v = new Vehiculo(placa, modelo, tipo, velocidad, precio);
       vehiculos.add(v);
       registrarBitacora("AGREGAR", v);
       limpiarFormulario();
    }
    private void eliminar(){
        Vehiculo seleccionado = tabla.getSelectionModel().getSelectedItem();
        if(seleccionado == null){
            new Alert(Alert.AlertType.WARNING,
                   "Selecciona un vehículo de la tabla primero.").showAndWait();
           return; 
        }
        vehiculos.remove(seleccionado);
        registrarBitacora("ELIMINAR", seleccionado);

    }
    private void limpiarFormulario(){
        txtplaca.clear();
        txtmodelo.clear();
        txtVelocidad.clear();
        txtprecio.clear();
        cmbtipo.setValue(null);
    }
    private boolean ExistePlaca(String placa){
        for(Vehiculo v: vehiculos){
            if(v.getplaca().equalsIgnoreCase(placa)){
                return true;
            }
        }
        return false;
    }
    private void mostrarError(String mensaje){
         new Alert(Alert.AlertType.ERROR, mensaje).showAndWait();
    }
    private void exportarCSV(Stage stage) {
       FileChooser fc = new FileChooser();
       fc.setTitle("Exportar CSV");
       fc.setInitialFileName("garaje.csv");
       fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV", "*.csv"));
       File archivo = fc.showSaveDialog(stage);
       if (archivo == null) return;
       try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))) {
           bw.write("placa,modelo,tipo,velocidadMax,precio");
           bw.newLine();
           for (Vehiculo v : vehiculos) {
               bw.write(v.getplaca() + "," + v.getmodelo() + "," + v.gettipo() + ","
                       + v.getVelocidadmaxima() + "," + v.precio());
               bw.newLine();
           }
           new Alert(Alert.AlertType.INFORMATION,
                   "Se exportaron " + vehiculos.size() + " vehículos.").showAndWait();
       } catch (IOException ex) {
           mostrarError("No se pudo exportar el CSV: " + ex.getMessage());
       }
   }
   private void importarCSV(Stage stage) {
       FileChooser fc = new FileChooser();
       fc.setTitle("Importar CSV");
       fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV", "*.csv"));
       File archivo = fc.showOpenDialog(stage);
       if (archivo == null) return;
       int cargados = 0;
       int descartados = 0;
       try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
           br.readLine();
           String linea;
           while ((linea = br.readLine()) != null) {
               if (linea.trim().isEmpty()) continue;
               Vehiculo v = parsearLinea(linea);
               if (v == null || ExistePlaca(v.getplaca())) {
                   descartados++;
               } else {
                   vehiculos.add(v);
                   cargados++;
               }
           }
           new Alert(Alert.AlertType.INFORMATION,
                   "Vehículos cargados: " + cargados + "\nLíneas descartadas: " + descartados)
                   .showAndWait();
       } catch (IOException ex) {
           mostrarError("No se pudo leer el CSV: " + ex.getMessage());
       }
   }
   
}