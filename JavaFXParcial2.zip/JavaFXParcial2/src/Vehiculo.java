import java.io.Serializable;

public class Vehiculo implements Serializable {

    private static final long serialVersionUID = 1L;

    private String placa;
    private String modelo;
    private String tipo;
    private int Velocidadmaxima;
    private int precio;
    
    public Vehiculo(String placa,String modelo,String tipo,int Velocidadmaxima,int precio){

        this.placa = placa;
        this.modelo = modelo;
        this.tipo = tipo;
        this.Velocidadmaxima = Velocidadmaxima;
        this.precio = precio;
    }
    
    public String getplaca(){
        return placa;
    }

    public void setplaca(){
        this.placa = placa;
    }

    public String getmodelo(){
        return modelo;
    }

    public void setmodelo(){
        this.modelo = modelo;
    }
    
    public String gettipo(){
        return tipo;
    }

    public void settipo(){
        this.tipo = tipo;
    }

    public int getVelocidadmaxima(){
        return Velocidadmaxima;
    }

    public void setVelocidadmaxima(){
        this.Velocidadmaxima = Velocidadmaxima;
    }

    public int precio(){
        return precio;
    }

    public void setprecio(){
        this.precio = precio;
    }

    @Override

    public String toString(){
         return placa + " - " + modelo + " (" + tipo + ", " + Velocidadmaxima + " km/h, $" + precio + ")";
    }
}